<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="windows-1251">
	
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title><?=isset($title) ? $title : 'Parfum de Paris' ?></title>
	<meta name="description" content="<?=isset($description) ? $description : 'Parfum de Paris' ?>">
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="shortcut icon" href="/favicon.ico" type="image/png">
	
	<!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display"> -->
	<link rel="stylesheet" href="/css/main.css?<?=mt_rand(1111,9999) ?>">

	<? include($_SERVER['DOCUMENT_ROOT'] . '/pixels.php') ?> 
</head>
<body>
<div class="vue">
	<header class="header">
		<div class="wrapper">
			<div class="header__inner">
				<div class="header__mobile-menu"></div>
				<a href="/" class="header__logo">
					<!-- <img src="/images/logo.png" alt="logo"> -->
				</a>
				<div class="header-info">
					<a href="/"><img class="mobile-logo"  src="/images/logo.png" alt="logo"></a>
					<!-- <div class="header-info__time">
						� 9:00 �� 18:00
					</div>
					<a href="tel:0800334869" class="header-info__phone">
						0 800 33 48 69
					</a>
					<div class="header-info__text">
						��������� �� �������
					</div> -->
				</div>
				<a @click="openBasket()" href="javascript:void(0)" class="header-basket">
					<div class="header-basket__counter">
						<span v-cloak>
							{{ basket.length }}
						</span>
					</div>
				</a>
			</div>
		</div>
	</header>
	<!-- <section class="main-menu">
		<div class="wrapper">
			<div class="main-menu__inner">
				<ul class="main-menu__list">
					<li class="main-menu__item">
						<a href="/about.html" class="main-menu__link">
							� ���
						</a>
					</li>

					<?php if (isset($_COOKIE['analog']) AND $_COOKIE['analog']) { ?>

						<li class="main-menu__item">
							<a href="/woman-compare.html" class="main-menu__link">
								������� ����������
							</a>
						</li>
						<li class="main-menu__item">
							<a href="/man-compare.html" class="main-menu__link">
								������� ����������
							</a>
						</li>

					<?php } else { ?>

						<li class="main-menu__item">
							<a href="/woman.html" class="main-menu__link">
								������� ����������
							</a>
						</li>
						<li class="main-menu__item">
							<a href="/man.html" class="main-menu__link">
								������� ����������
							</a>
						</li>

					<?php } ?>

					<li class="main-menu__item">
						<a href="/samples-preview.html" class="main-menu__link">
							��������
						</a>
					</li>

					
					<li class="main-menu__item">
						<a href="/contact.html" class="main-menu__link">
							��������
						</a>
					</li>
					<li class="main-menu__item">
						<a @click="showInfo()" href="#footer" class="main-menu__link">
							����������
						</a>
					</li>
				</ul>

			</div>
		</div>
	</section> -->