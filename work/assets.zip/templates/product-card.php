
						<div class="product-card">
							
							<div v-if="product.new == 1" class="product-card__label-new">
								<span>
									new
								</span>
							</div>
							<div v-if="product.best == 1" class="product-card__label-bestseller">
								BESTSELLER
							</div>
							<div v-if="product.hit == 1" class="product-card__label-niche"> 
								niche
							</div>
							<div class="product-card__img">
								<img v-if="product.img" :src="['/assets/img/landing_good/' + product.img]" :alt="product.analog">
							</div>
							<div class="product-card__info-wrapper">
								<div class="product-card__info">
									<div class="product-card__name">
										<strong>{{ product.bname }}</strong><br/>
										{{ product.name }}
									</div>
									<div class="product-card__number">
										<div class="product-card__number-icon">
										<span>
											<!-- {{ product.name }} -->
										</span>
										</div>
									</div>

									<div class="product-card__price"> 
										<div class="product-card__price-col active">
											<span>
												{{ product.price }}.
												 <sup>00</sup>
											</span>
										</div> 
										<span class="product-card__price-text">&nbsp; &nbsp; ���.</span>

									</div>

									<div class="product-card__volume">2,5 ��</div>
								
									<div class="product-card__description">

										�������� �������: <b>{{ product.filter2 }}</b>
									</div>
								</div>
								<form class="product-card__controllers">
									<button @click="addToCart(product, $event)" type="submit" class="product-card__button">
										{{ hasInBasket(product.art) ? '��������� � �������' : '� �������' }}
									</button>
								</form>
							</div>
						</div>
					